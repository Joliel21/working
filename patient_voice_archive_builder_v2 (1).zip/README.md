# Patient Voice Archive Builder — Version 2

This version clones the structure used by the existing RARE Revolution series
downloads.

## Exact output format

```text
patient-voice.zip
├── manifest.csv
└── images/
    ├── patient-voice-xxxxxxxx.png
    └── ...
```

`manifest.csv` uses exactly these columns and this order:

```text
title,article_url,archive_image_url,filename,status
```

Image filenames follow the existing convention:

```text
<series-slug>-<first-8-characters-of-SHA1(article_url)>.<extension>
```

For Patient Voice, every manifest row uses `Patient Voice` in the `title`
column. This matches the behavior of existing archives such as CEO Series,
where the manifest stores the series label rather than each article headline.

## Build the archive

```bash
python -m pip install -r requirements.txt
python build_series_archive_v2.py
```

This creates `patient-voice.zip`.

## Validate it

```bash
python validate_archive.py patient-voice.zip
```

A successful result starts with `PASS`.

## Test only the first category page

```bash
python build_series_archive_v2.py --max-pages 1
```

## Reuse for another category

```bash
python build_series_archive_v2.py   --url "CATEGORY_URL"   --title "Series Name"   --slug "series-slug"   --output "series-slug.zip"
```

## Hand it to the other chat

Upload the generated `patient-voice.zip`, not this builder ZIP, and say:

> Create the Patient Voice Series Spread handoff from this archive using the
> established Series Spread Integration Workflow.

The archive contains no extra README or tooling. Only `manifest.csv` and
`images/` are placed inside it, matching the established downloads.
