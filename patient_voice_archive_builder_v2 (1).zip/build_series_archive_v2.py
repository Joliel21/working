#!/usr/bin/env python3
"""
RARE Revolution archive builder v2

Creates a source archive matching the existing series-download format:

    patient-voice.zip
    ├── images/<series-slug>-<sha1(article_url)[:8]>.<ext>
    └── manifest.csv

Exact manifest columns:
    title,article_url,archive_image_url,filename,status
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import mimetypes
import re
import shutil
import sys
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

DEFAULT_URL = "https://rarerevolutionmagazine.com/category/rare-insights/patient-voice/"
DEFAULT_TITLE = "Patient Voice"
DEFAULT_SLUG = "patient-voice"
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0 Safari/537.36"
)

MANIFEST_COLUMNS = [
    "title",
    "article_url",
    "archive_image_url",
    "filename",
    "status",
]


@dataclass
class Item:
    title: str
    article_url: str
    archive_image_url: str
    filename: str = ""
    status: str = ""


def clean(value: str | None) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def canonical_url(base: str, value: str | None) -> str:
    url = urljoin(base, value or "")
    parsed = urlparse(url)
    if not parsed.scheme or not parsed.netloc:
        return ""
    path = re.sub(r"/{2,}", "/", parsed.path)
    if path and not path.endswith("/") and "." not in Path(path).name:
        path += "/"
    return parsed._replace(path=path, fragment="", query="").geturl()


def same_site(url: str) -> bool:
    host = urlparse(url).netloc.lower()
    return host == "rarerevolutionmagazine.com" or host.endswith(".rarerevolutionmagazine.com")


def session() -> requests.Session:
    s = requests.Session()
    s.headers.update(
        {
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
        }
    )
    return s


def get_soup(s: requests.Session, url: str, timeout: int) -> BeautifulSoup:
    response = s.get(url, timeout=timeout)
    response.raise_for_status()
    return BeautifulSoup(response.text, "html.parser")


def find_next_page(soup: BeautifulSoup, current_url: str) -> str:
    candidates = [
        soup.select_one("a.next.page-numbers"),
        soup.select_one("a[rel='next']"),
        soup.select_one(".nav-links a.next"),
        soup.select_one(".pagination a.next"),
    ]
    for node in candidates:
        if node and node.get("href"):
            return canonical_url(current_url, node.get("href"))

    for node in soup.find_all("a", href=True):
        label = clean(node.get_text(" ", strip=True)).lower()
        aria = clean(node.get("aria-label")).lower()
        if label in {"next", "next page", "older posts", "›", "»"} or "next" in aria:
            return canonical_url(current_url, node.get("href"))
    return ""


def category_pages(
    s: requests.Session,
    start_url: str,
    timeout: int,
    max_pages: int | None,
) -> list[str]:
    pages: list[str] = []
    seen: set[str] = set()
    current = canonical_url(start_url, start_url)

    while current and current not in seen:
        seen.add(current)
        pages.append(current)
        if max_pages and len(pages) >= max_pages:
            break
        soup = get_soup(s, current, timeout)
        current = find_next_page(soup, current)

    return pages


def article_links(soup: BeautifulSoup, page_url: str) -> list[str]:
    selectors = [
        "article .entry-title a[href]",
        "article h1 a[href]",
        "article h2 a[href]",
        "article h3 a[href]",
        ".elementor-post__title a[href]",
        ".post-title a[href]",
        ".blog-post-title a[href]",
        "main article a[href]",
    ]

    links: list[str] = []
    seen: set[str] = set()

    for selector in selectors:
        found = []
        for anchor in soup.select(selector):
            href = canonical_url(page_url, anchor.get("href"))
            if (
                href
                and same_site(href)
                and "/category/" not in href
                and href not in seen
            ):
                seen.add(href)
                found.append(href)
        links.extend(found)
        if found:
            break

    return links


def metadata(soup: BeautifulSoup, article_url: str) -> tuple[str, str]:
    title = ""
    for selector, attribute in [
        ("meta[property='og:title']", "content"),
        ("meta[name='twitter:title']", "content"),
        ("h1.entry-title", None),
        ("article h1", None),
        ("main h1", None),
        ("h1", None),
    ]:
        node = soup.select_one(selector)
        if node:
            title = clean(node.get(attribute) if attribute else node.get_text(" ", strip=True))
            if title:
                break

    image = ""
    for selector, attribute in [
        ("meta[property='og:image']", "content"),
        ("meta[name='twitter:image']", "content"),
        ("meta[property='og:image:secure_url']", "content"),
        ("article img.wp-post-image", "src"),
        ("article img", "src"),
        ("main img", "src"),
    ]:
        node = soup.select_one(selector)
        if node and node.get(attribute):
            image = urljoin(article_url, node.get(attribute))
            break

    return title, image


def extension(response: requests.Response, image_url: str) -> str:
    ext = Path(urlparse(image_url).path).suffix.lower()
    allowed = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
    if ext in allowed:
        return ".jpg" if ext == ".jpeg" else ext

    content_type = response.headers.get("content-type", "").split(";")[0].strip()
    guessed = mimetypes.guess_extension(content_type) or ".jpg"
    if guessed in {".jpe", ".jpeg"}:
        return ".jpg"
    return guessed


def is_probably_image(path: Path) -> bool:
    if not path.exists() or path.stat().st_size < 100:
        return False
    head = path.read_bytes()[:16]
    signatures = (
        b"\x89PNG\r\n\x1a\n",
        b"\xff\xd8\xff",
        b"GIF87a",
        b"GIF89a",
        b"RIFF",
    )
    return any(head.startswith(sig) for sig in signatures)


def download(
    s: requests.Session,
    item: Item,
    images_dir: Path,
    series_slug: str,
    timeout: int,
) -> None:
    if not item.archive_image_url:
        item.status = "missing_image"
        return

    digest = hashlib.sha1(item.article_url.encode("utf-8")).hexdigest()[:8]
    temporary = images_dir / f".{series_slug}-{digest}.part"

    try:
        response = s.get(item.archive_image_url, timeout=timeout, stream=True)
        response.raise_for_status()
        ext = extension(response, item.archive_image_url)
        filename = f"{series_slug}-{digest}{ext}"
        destination = images_dir / filename

        with temporary.open("wb") as handle:
            for chunk in response.iter_content(64 * 1024):
                if chunk:
                    handle.write(chunk)

        if not is_probably_image(temporary):
            raise ValueError("Downloaded content is not a recognized image.")

        temporary.replace(destination)
        item.filename = filename
        item.status = "downloaded"
    except Exception:
        temporary.unlink(missing_ok=True)
        item.filename = ""
        item.status = "failed"


def write_manifest(path: Path, items: list[Item]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=MANIFEST_COLUMNS)
        writer.writeheader()
        for item in items:
            writer.writerow(
                {
                    "title": item.title,
                    "article_url": item.article_url,
                    "archive_image_url": item.archive_image_url,
                    "filename": item.filename,
                    "status": item.status,
                }
            )


def validate(build_dir: Path) -> None:
    manifest = build_dir / "manifest.csv"
    images = build_dir / "images"

    if not manifest.is_file():
        raise RuntimeError("manifest.csv was not created.")
    if not images.is_dir():
        raise RuntimeError("images/ was not created.")

    with manifest.open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != MANIFEST_COLUMNS:
            raise RuntimeError(
                f"Wrong manifest columns: {reader.fieldnames}; expected {MANIFEST_COLUMNS}"
            )
        rows = list(reader)

    if not rows:
        raise RuntimeError("No articles were discovered.")

    for row in rows:
        if row["status"] == "downloaded":
            image = images / row["filename"]
            if not is_probably_image(image):
                raise RuntimeError(f"Missing or invalid image: {row['filename']}")


def zip_build(build_dir: Path, output: Path) -> None:
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.write(build_dir / "manifest.csv", "manifest.csv")
        for image in sorted((build_dir / "images").iterdir()):
            if image.is_file():
                archive.write(image, f"images/{image.name}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a RARE Revolution series archive.")
    parser.add_argument("--url", default=DEFAULT_URL)
    parser.add_argument("--title", default=DEFAULT_TITLE)
    parser.add_argument("--slug", default=DEFAULT_SLUG)
    parser.add_argument("--output", default="patient-voice.zip")
    parser.add_argument("--max-pages", type=int)
    parser.add_argument("--timeout", type=int, default=30)
    parser.add_argument("--delay", type=float, default=0.5)
    parser.add_argument("--keep-build-folder", action="store_true")
    args = parser.parse_args()

    output = Path(args.output).resolve()
    build_dir = output.with_suffix("")
    if build_dir.exists():
        shutil.rmtree(build_dir)
    images_dir = build_dir / "images"
    images_dir.mkdir(parents=True)

    s = session()

    try:
        pages = category_pages(s, args.url, args.timeout, args.max_pages)
        urls: list[str] = []
        seen: set[str] = set()

        for page_number, page_url in enumerate(pages, 1):
            print(f"Category page {page_number}: {page_url}")
            soup = get_soup(s, page_url, args.timeout)
            for url in article_links(soup, page_url):
                if url not in seen:
                    seen.add(url)
                    urls.append(url)
            time.sleep(args.delay)

        items: list[Item] = []
        for index, article_url in enumerate(urls, 1):
            print(f"Article {index}/{len(urls)}: {article_url}")
            try:
                soup = get_soup(s, article_url, args.timeout)
                _, image_url = metadata(soup, article_url)
                item = Item(
                    title=args.title,
                    article_url=article_url,
                    archive_image_url=image_url,
                )
                download(s, item, images_dir, args.slug, args.timeout)
            except Exception:
                item = Item(
                    title=args.title,
                    article_url=article_url,
                    archive_image_url="",
                    status="failed",
                )
            items.append(item)
            time.sleep(args.delay)

        write_manifest(build_dir / "manifest.csv", items)
        validate(build_dir)
        zip_build(build_dir, output)

        downloaded = sum(item.status == "downloaded" for item in items)
        failed = len(items) - downloaded
        print(f"\nCreated: {output}")
        print(f"Articles: {len(items)}")
        print(f"Downloaded: {downloaded}")
        print(f"Missing/failed: {failed}")

        if not args.keep_build_folder:
            shutil.rmtree(build_dir)

        return 0
    except Exception as exc:
        print(f"\nBuild failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
