#!/usr/bin/env python3
"""Validate that an output ZIP matches the established source-archive contract."""

from __future__ import annotations

import argparse
import csv
import io
import zipfile
from pathlib import PurePosixPath

COLUMNS = ["title", "article_url", "archive_image_url", "filename", "status"]

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", nargs="?", default="patient-voice.zip")
    args = parser.parse_args()

    with zipfile.ZipFile(args.archive) as archive:
        names = archive.namelist()
        if "manifest.csv" not in names:
            raise SystemExit("FAIL: manifest.csv is missing.")

        unexpected = [
            name for name in names
            if name != "manifest.csv" and not name.startswith("images/")
        ]
        if unexpected:
            raise SystemExit(f"FAIL: unexpected paths: {unexpected}")

        with archive.open("manifest.csv") as raw:
            reader = csv.DictReader(io.TextIOWrapper(raw, encoding="utf-8-sig"))
            if reader.fieldnames != COLUMNS:
                raise SystemExit(
                    f"FAIL: columns are {reader.fieldnames}; expected {COLUMNS}"
                )
            rows = list(reader)

        if not rows:
            raise SystemExit("FAIL: manifest has no rows.")

        missing = []
        for row in rows:
            if row["status"] == "downloaded":
                expected = f"images/{row['filename']}"
                if expected not in names:
                    missing.append(expected)

        if missing:
            raise SystemExit(f"FAIL: missing image files: {missing}")

        image_count = sum(
            1 for name in names
            if name.startswith("images/") and not name.endswith("/")
        )
        downloaded = sum(row["status"] == "downloaded" for row in rows)

        print("PASS")
        print(f"Manifest rows: {len(rows)}")
        print(f"Downloaded rows: {downloaded}")
        print(f"Image files: {image_count}")
        return 0

if __name__ == "__main__":
    raise SystemExit(main())
